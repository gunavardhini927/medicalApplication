package com.example.medicalapp

class DoctorsList {
}