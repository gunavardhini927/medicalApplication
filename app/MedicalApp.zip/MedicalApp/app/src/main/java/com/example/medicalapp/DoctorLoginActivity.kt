package com.example.medicalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DoctorLoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_login)

        val DrSignUpNow = findViewById<Button>(R.id.Id_Dr_Sign_Up_Now)

        DrSignUpNow.setOnClickListener{
            val intent = Intent(this,DoctorRegistrationActivity::class.java)
            startActivity(intent)
        }
    }
}