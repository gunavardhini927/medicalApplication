package com.example.medicalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.widget.AppCompatEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class Patient_Registration_Activity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var fullname: AppCompatEditText;
    private lateinit var email: AppCompatEditText;
    private lateinit var phoneNumber: AppCompatEditText
    private lateinit var password: AppCompatEditText
    private lateinit var address: AppCompatEditText;
    private lateinit var dob: AppCompatEditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_patient_registration)
        auth = Firebase.auth


        fullname = findViewById(R.id.ed_full_name)
        email = findViewById(R.id.ed_email)
        phoneNumber = findViewById(R.id.ed_phone_no)
        password = findViewById(R.id.ed_password)
        address = findViewById(R.id.ed_address);
        dob = findViewById(R.id.ed_dob);
        var saveandcontinue_button = findViewById<Button>(R.id.btnsaveandcontinue1);
        saveandcontinue_button.setOnClickListener {
            registerUser()
        }
    }


    private fun registerUser() {
        if(fullname.text.toString().trim().isEmpty()){
            fullname.setError("Please enter Full Name");
            fullname.requestFocus();
        }
        else if(email.text.toString().trim().isEmpty()){
            email.setError("Please enter your email ")
            email.requestFocus()
        }
        else if(!Patterns.EMAIL_ADDRESS.matcher(email.text.toString().trim()).matches()){
            email.setError("Email pattern is not matchecd")
            email.requestFocus()
        }
        else if(phoneNumber.text!!.length<10){
            phoneNumber.setError("Number can't be less than 10 digits")
            phoneNumber.requestFocus()
        }
        else if(address.text!!.length<10){
            address.setError("Address can't be empty")
            address.requestFocus()
        }
        else if(dob.text.toString().length < 6){
            dob.setError("dob cannot be empty")
            dob.requestFocus()
        }
        else{
            auth.createUserWithEmailAndPassword(email.text.toString().trim(), password.text.toString().trim()).addOnCompleteListener(
            ) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(
                        this,
                        "User registered successfully",
                        Toast.LENGTH_SHORT
                    ).show()
                    var fireBaseData= FirebaseDatabase.getInstance()


                    var User1=UserProfile();
                    User1.address=address.text.toString().trim();
                    User1.fullname=fullname.text.toString().trim();
                    User1.email=email.text.toString().trim();
                    User1.dob=dob.text.toString().trim()
                    User1.phoneNumber=phoneNumber.text.toString().trim()
                    fireBaseData.getReference("Users").child(FirebaseAuth.getInstance().currentUser!!.uid).setValue(User1).addOnCompleteListener(this){
                        if(it.isSuccessful){
                            Toast.makeText(
                                this,
                                "User data saved successfully",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                        else{
                            Toast.makeText(
                                this,
                                "User data not saved due to error",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                    }
                    val intent = Intent(this, PatientLoginActivity::class.java)
                    startActivity(intent)
                } else {

                    Toast.makeText(
                        this,
                        "registration failed ",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }




    }
}
        
        

        