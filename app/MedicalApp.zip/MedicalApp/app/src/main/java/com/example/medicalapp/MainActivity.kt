package com.example.medicalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val DrBtn = findViewById<Button>(R.id.Id_DoctorBtn)

        DrBtn.setOnClickListener{
            val intent = Intent(this,DoctorLoginActivity::class.java)
            startActivity(intent)
        }

        val PtBtn = findViewById<Button>(R.id.Id_PatientBtn)

        PtBtn.setOnClickListener{
            val intent = Intent(this,PatientLoginActivity::class.java)
            startActivity(intent)
        }
    }

}