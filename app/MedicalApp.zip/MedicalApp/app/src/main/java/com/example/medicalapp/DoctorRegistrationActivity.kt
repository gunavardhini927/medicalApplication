package com.example.medicalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class DoctorRegistrationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_registration)

        val DrSaveAndContinue = findViewById<Button>(R.id.Id_Dr_SaveAndContinue)

        DrSaveAndContinue.setOnClickListener{
            val intent = Intent(this,DoctorLoginActivity::class.java)
            startActivity(intent)
        }
    }
}