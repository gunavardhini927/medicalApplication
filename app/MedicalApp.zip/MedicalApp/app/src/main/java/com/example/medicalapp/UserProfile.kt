package com.example.medicalapp

class UserProfile {
    var fullname:String?=null;
    var phoneNumber:String?=null;
    var email:String?=null;
    var dob:String?=null;
    var address:String?=null;
}