package com.example.medicalapp

import android.view.LayoutInflater

import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView

import androidx.recyclerview.widget.RecyclerView

import com.bumptech.glide.Glide


class DoctorAdapter(
    private val doctorList: ArrayList<UserProfileTwo>
) :RecyclerView.Adapter<DoctorAdapter.DoctorViewHolder>() {

    class DoctorViewHolder (itemView: View) : RecyclerView.ViewHolder(itemView) {
        val fullname: TextView = itemView.findViewById(R.id.Id_tv_name_one)
        val qualification: TextView = itemView.findViewById(R.id.Id_tv_qual_one)
        val experience: TextView = itemView.findViewById(R.id.Id_tv_exp_one)
        val Image: ImageView = itemView.findViewById(R.id.cardiodr)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DoctorViewHolder {
        val itemView = LayoutInflater.from(parent.context)
            .inflate(R.layout.activity_cardiology, parent, false)
        return DoctorViewHolder(itemView)

    }

    override fun onBindViewHolder(holder: DoctorViewHolder, position: Int) {
        val currentitem = doctorList[position]
        holder.fullname.text = currentitem.fullname
        holder.qualification.text = currentitem.qualification.toString()
        holder.experience.text = currentitem.experience.toString()
        Glide.with(holder.Image.context).load(currentitem.profileImgUrl)
            .into(holder.Image)
    }

    override fun getItemCount(): Int {
        return doctorList.size
    }
}


