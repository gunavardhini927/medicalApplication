package com.example.medicalapp.doctorList

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.medicalapp.*
import com.example.medicalapp.R
import com.example.medicalapp.databinding.ActivityNeurologyDoctorListBinding
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*


class NeurologyDoctorList : AppCompatActivity() {
    private lateinit var ref: DatabaseReference
    private lateinit var RecyclerView: RecyclerView
    private lateinit var DoctorArrayList: ArrayList<UserProfileTwo>

    var firebaseUser: FirebaseUser? = null
    private var Id_tv_name_one: TextView? = null
    private var uid = ""

    //    var resultLauncher =
//        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
//            if (result.resultCode == Activity.RESULT_OK) {
//                getdata()
//            }
//        }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_neurology_doctor_list)

        Id_tv_name_one = findViewById(R.id.Id_tv_name_one)

        uid = intent.getStringExtra("message_key")!!

        firebaseUser = FirebaseAuth.getInstance().currentUser
        ref = FirebaseDatabase.getInstance().reference.child("Doctors")

        RecyclerView = findViewById(R.id.list)

        RecyclerView.layoutManager = LinearLayoutManager(this)
        RecyclerView.setHasFixedSize(true)
        DoctorArrayList = arrayListOf<UserProfileTwo>()

        // getdata()


        var intent: Intent = getIntent()
        var str = intent.getStringExtra("message_key")
        val query: Query =
            FirebaseDatabase.getInstance().getReference("Doctors").orderByChild("department")
                .equalTo(str)
        query.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(dataSnapshot: DataSnapshot) {
                for (childSnapshot in dataSnapshot.children) {
                    val yourModel: UserProfileTwo? =
                        childSnapshot.getValue(UserProfileTwo::class.java)
                    DoctorArrayList.add(yourModel!!)
                    //user!!.setUID(userSnapshot.key)
                }

                RecyclerView.adapter =
                    DoctorAdapter(DoctorArrayList)
            }

            override fun onCancelled(error: DatabaseError) {
                TODO("Not yet implemented")
            }
        })
    }

//        private fun getdata() {
//
//            ref = FirebaseDatabase.getInstance().getReference("Doctors")
//
//            ref.addValueEventListener(object : ValueEventListener {
//                override fun onDataChange(snapshot: DataSnapshot) {
//
//                    if (snapshot.exists()) {
////                    var menuList = try {
////                        snapshot.child("Menu").value as ArrayList<Menu>
////                    } catch (e: Exception) {
////                        arrayListOf<Menu>()
////                    }
//
//
//                        for (userSnapshot in snapshot.children) {
//                            Log.e("Daattt", userSnapshot.toString())
//
//                           val data = UserProfileTwo()
//                            data.fullname = userSnapshot.child("fullname").value.toString()
//                            data.profileImgUrl =
//                                userSnapshot.child("profileImgUrl").value.toString()
//                            data.qualification = userSnapshot.child("qualification").value.toString()
//                            data.experience = userSnapshot.child("experience").value.toString()
//
//                            val menuList = ArrayList<UserProfileTwo>()
//
//                            for (menuSnapshot in userSnapshot.child("Menu").children) {
//                                menuList.add(menuSnapshot.getValue(UserProfileTwo::class.java)!!)
//                            }
//
//                            //data.DishModel = menuList
//
////                        val user = userSnapshot.getValue(CoustomerRestaurantData::class.java)
//
////
////                            if (data?.uid == uid) {
////                                try {
////                                    menuArrayList = data.DishModel!!
////                                } catch (e: Exception) {
////                                    arrayListOf<DishModel>()
////                                }
////                            }
//                        }
//
//                        RecyclerView.adapter = DoctorAdapter(ArrayList)
//                    }
//
//                }
//
//                override fun onCancelled(error: DatabaseError) {
//                    TODO("Not yet implemented")
//                }
//            })

    }


