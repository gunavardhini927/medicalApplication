package com.example.medicalapp

data class appointmentDetails (
    var date:String?=null,
    var time:String?=null,
)