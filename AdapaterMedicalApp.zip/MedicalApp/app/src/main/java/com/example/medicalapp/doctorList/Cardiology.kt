package com.example.medicalapp.doctorList

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.medicalapp.R
import com.example.medicalapp.databinding.ActivityCardiologyBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class Cardiology : AppCompatActivity() {

    private lateinit var binding : ActivityCardiologyBinding
    private lateinit var databasereference : DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCardiologyBinding.inflate(layoutInflater)
        setContentView(binding.root)
//        binding.textView.setOnClickListener {
//
//            val dept : String = binding.textView.text.toString()
//            if  (dept.isNotEmpty()){
//
//                readData(dept)
//
//            }else{
//
//                Toast.makeText(this,"Please enter the department", Toast.LENGTH_SHORT).show()
//
//            }
//
       }

    }

//    private fun readData(dept: String) {
//
//        databasereference = FirebaseDatabase.getInstance().getReference("Doctors")
//        databasereference.child(dept).get().addOnSuccessListener {
//
//            if (it.exists()){
//               // val profileImgUrl = it.child("profileImgUrl").value
//                val fullname = it.child("fullname").value
//                val qualification = it.child("qualification").value
//                val experience = it.child("experience").value
//                Toast.makeText(this,"Successfuly Read", Toast.LENGTH_SHORT).show()
//
//                binding.IdTvNameOne.text = fullname.toString()
//                binding.IdTvQualOne.text = qualification.toString()
//                binding.IdTvExpOne.text = experience.toString()
//
//            }else{
//
//                Toast.makeText(this,"User Doesn't Exist", Toast.LENGTH_SHORT).show()
//
//            }
//
//        }.addOnFailureListener{
//
//            Toast.makeText(this,"Failed", Toast.LENGTH_SHORT).show()
//
//
//        }
//
//
//
//    }
//}


