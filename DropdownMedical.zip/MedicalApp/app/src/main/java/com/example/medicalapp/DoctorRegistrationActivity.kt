package com.example.medicalapp

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.*
import androidx.appcompat.widget.AppCompatEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.ktx.Firebase

class DoctorRegistrationActivity : AppCompatActivity() {
    private lateinit var auth: FirebaseAuth
    private lateinit var fullname: AppCompatEditText;
    private lateinit var email: AppCompatEditText;
    private lateinit var phoneNumber: AppCompatEditText
    private lateinit var password: AppCompatEditText
    private lateinit var address: AppCompatEditText;
    private lateinit var medicalid: AppCompatEditText;
    private lateinit var qualification: AppCompatEditText;
    private lateinit var experience: AppCompatEditText;


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor_registration)
        // access the items of the list
        val Departments = resources.getStringArray(R.array.Departments)

        // access the spinner
        val spinner = findViewById<Spinner>(R.id.spinner)
        if (spinner != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, Departments)
            spinner.adapter = adapter

            spinner.onItemSelectedListener = object :
                AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View, position: Int, id: Long) {
                    Toast.makeText(this@DoctorRegistrationActivity,
                        getString(R.string.selected_item) + " " +
                                "" + Departments[position], Toast.LENGTH_SHORT).show()
                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        auth = Firebase.auth
        fullname = findViewById(R.id.doc_full_name)
        email = findViewById(R.id.doc_email)
        phoneNumber = findViewById(R.id.doc_phoneno)
        password = findViewById(R.id.doc_passsword)
        medicalid = findViewById(R.id.doc_medical_id);
        qualification = findViewById(R.id.doc_qualification)
        experience = findViewById(R.id.doc_experience)
        var doc_reg_save=findViewById<Button>(R.id.Id_Dr_SaveAndContinue)
        doc_reg_save.setOnClickListener {
            registerUser()
        }
    }

    private fun registerUser() {
        if (fullname.text.toString().trim().isEmpty()) {
            fullname.setError("Please enter Full Name");
            fullname.requestFocus();
        } else if (medicalid.text.toString().trim().isEmpty()) {
            medicalid.setError("Please enter your Medical Id ")
            medicalid.requestFocus()
        } else if (email.text.toString().trim().isEmpty()) {
            email.setError("Please enter your email ")
            email.requestFocus()
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email.text.toString().trim()).matches()) {
            email.setError("Email pattern is not matchecd")
            email.requestFocus()
        } else if (phoneNumber.text!!.length < 10) {
            phoneNumber.setError("Number can't be less than 10 digits")
            phoneNumber.requestFocus()
        } else if (address.text.toString().trim().isEmpty()) {
            address.setError("Address can't be empty")
            address.requestFocus()
        } else if (password.text.toString().trim().isEmpty()) {
            password.setError("password can't be empty")
            password.requestFocus()
        } else if (qualification.text.toString().trim().isEmpty()) {
            qualification.setError("Qualification can't be empty")
            qualification.requestFocus()
        } else if (experience.text.toString().trim().isEmpty()) {
            experience.setError("Experience can't be empty")
            experience.requestFocus()
        } else {
            auth.createUserWithEmailAndPassword(
                email.text.toString().trim(),
                password.text.toString().trim()
            ).addOnCompleteListener(
            ) { task ->
                if (task.isSuccessful) {
                    Toast.makeText(
                        this,
                        "User registered successfully",
                        Toast.LENGTH_SHORT
                    ).show()

                    var fireBaseData = FirebaseDatabase.getInstance()
                    var User2 = UserProfileTwo();
                    User2.address = address.text.toString().trim();
                    User2.fullname = fullname.text.toString().trim();
                    User2.email = email.text.toString().trim();
                    User2.qualification = qualification.text.toString().trim()
                    User2.phoneNumber = phoneNumber.text.toString().trim()
                    User2.medicalid = medicalid.text.toString().trim()
                    User2.experience = experience.text.toString().trim()

                    fireBaseData.getReference("Doctors")
                        .child(FirebaseAuth.getInstance().currentUser!!.uid).setValue(User2)
                        .addOnCompleteListener(this) {
                            if (it.isSuccessful) {
                                Toast.makeText(
                                    this,
                                    "User data saved successfully",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } else {
                                Toast.makeText(
                                    this,
                                    "User data not saved due to error",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    val intent = Intent(this, DoctorLoginActivity::class.java)
                    startActivity(intent)
                } else {

                    Toast.makeText(
                        this,
                        "registration failed ",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
}}






