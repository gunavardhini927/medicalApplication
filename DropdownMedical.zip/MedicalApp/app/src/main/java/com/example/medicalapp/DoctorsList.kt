package com.example.medicalapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class DoctorsList : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctors_list2)
    }
}