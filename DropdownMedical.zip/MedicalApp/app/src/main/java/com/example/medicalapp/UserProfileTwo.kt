package com.example.medicalapp

class UserProfileTwo {
    var fullname:String?=null;
    var phoneNumber:String?=null;
    var email:String?=null;
    var qualification:String?=null;
    var address:String?=null;
    var experience:String?=null;
    var medicalid:String?=null;

}