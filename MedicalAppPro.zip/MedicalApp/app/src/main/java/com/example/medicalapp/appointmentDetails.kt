package com.example.medicalapp

data class appointmentDetails (
    var doctor:UserProfileTwo?=null,
    var date:String?=null,
    var time:String?=null,
    var PatientName: String?=null,
)

