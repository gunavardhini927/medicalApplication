package com.example.medicalapp.department

data class DepartmentModel(
    val DeptImage: String?= null,
    val DeptName: String?= null

)
