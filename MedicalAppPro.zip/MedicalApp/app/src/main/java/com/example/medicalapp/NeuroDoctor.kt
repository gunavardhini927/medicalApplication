package com.example.medicalapp

class NeuroDoctor {

}