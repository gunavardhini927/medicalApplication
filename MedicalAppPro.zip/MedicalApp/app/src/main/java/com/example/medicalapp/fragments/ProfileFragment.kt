package com.example.medicalapp.fragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast

import androidx.fragment.app.Fragment



import com.example.medicalapp.databinding.FragmentProfileBinding

import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase


class ProfileFragment : Fragment() {

    //  private lateinit var binding: FragmentProfileBinding
    private lateinit var database: DatabaseReference

    //  override fun onCreate(savedInstanceState: Bundle?) {
    //     super.onCreate(savedInstanceState)

    //   binding = FragmentProfileBinding.inflate(layoutInflater)
    //   setContentView(this,binding.root)
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentProfileBinding.inflate(layoutInflater)

        binding.btnUpdate.setOnClickListener {

            val fullname = binding.fullNameText.text.toString()
            val email = binding.emailIdText.text.toString()
            val dob = binding.DOB.text.toString()
            val phoneNumber = binding.phnNoText.text.toString()
            UpdateData(fullname, email, dob, phoneNumber)

        }

        return binding.root
    }


    private fun UpdateData(fullname: String, email: String, dob: String, phoneNumber: String) {


        database = FirebaseDatabase.getInstance().getReference("Users")
        val user = mapOf<String, String>(
            "fullname" to fullname,
            "email" to email,
            "dob" to dob,
            "phoneNumber" to phoneNumber,
        )

        database.child("Users").updateChildren(user).addOnSuccessListener {

//           binding.fullNameText.text.toString()
//           binding.emailIdText.text.toString().trim()
//            binding.DOB.text.toString().trim()
//           binding.phnNoText.text.toString().trim()


           // Toast.makeText(this, "Successfully Updated", Toast.LENGTH_SHORT).show()
            Toast.makeText(context,"Successfully added", Toast.LENGTH_LONG).show()

        }.addOnFailureListener {

            Toast.makeText(context, "Failed to Update", Toast.LENGTH_SHORT).show()

        }
    }
}






