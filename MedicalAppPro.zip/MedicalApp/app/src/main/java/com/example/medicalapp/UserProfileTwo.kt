package com.example.medicalapp

import java.io.Serializable

class UserProfileTwo : Serializable {
    var profileImgUrl:String?=null;
    var fullname:String?=null;
    var phoneNumber:String?=null;
    var email:String?=null;
    var qualification:String?=null;
    var experience:String?=null;
    var medicalid:String?=null;
    var department:String?=null;

}